# RMF Codespace Starter (API + World + Custom UI)

A tiny starter that brings up the Open‑RMF API + demo world and a simple React UI that can talk to the API **in GitHub Codespaces** or locally.

## Quick Start (Codespaces)

1. Open a terminal at the repo root.
2. Make port 8000 **Public** in the Ports tab.
3. Set the UI to call your forwarded 8000 URL:
   ```bash
   echo "VITE_RMF_SERVER=https://8000-$CODESPACE_NAME.github.dev" > .env
   ```
4. Build & start:
   ```bash
   docker compose up -d --build
   ```
5. Open the globes for:
   - **8000** → append `/openapi.json` (should be JSON).
   - **3000** → the UI dashboard. Click **Login** (mock), then **Ping API**.

If you change `.env`, rebuild the UI:
```bash
docker compose up -d --build ui
```

## Local (non-Codespaces)
Create `.env` and point to your API:
```
VITE_RMF_SERVER=http://localhost:8000
```
Then:
```
docker compose up -d --build
```

## What’s inside
- **api**: `ghcr.io/open-rmf/rmf-web/api-server:jazzy-nightly`
- **world**: `ghcr.io/open-rmf/rmf/rmf_demos:jazzy-rmf-latest` (hotel world), pointing to the API’s internal hostname
- **ui**: Vite + React TypeScript app. The container injects a runtime config file so the UI reads `VITE_RMF_SERVER` at **runtime** (no rebuild required for URL changes).

## Notes
- This UI uses a **mock login** (no Keycloak/Auth0). The **Login** button just stores a local token so you can navigate the app and hit the API.
- Replace the mock auth with your provider later if needed.
