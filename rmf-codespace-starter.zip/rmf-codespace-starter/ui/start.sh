#!/bin/sh
set -e
# Create runtime config from env var (fallback provided by compose)
: "${VITE_RMF_SERVER:=http://api:8000}"
mkdir -p ./dist
cat > ./dist/config.json <<EOF
{"RMF_SERVER":"$VITE_RMF_SERVER"}
EOF
# serve the built app
npx --yes serve -sn dist -l 3000
