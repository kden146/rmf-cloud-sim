import React, { createContext, useContext, useEffect, useState } from 'react'

type User = { name: string } | null

type AuthCtx = {
  user: User
  login: (name: string) => void
  logout: () => void
}

const Ctx = createContext<AuthCtx | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User>(null)

  useEffect(() => {
    const raw = localStorage.getItem('rmf_user')
    if (raw) setUser(JSON.parse(raw))
  }, [])

  const login = (name: string) => {
    const u = { name }
    localStorage.setItem('rmf_user', JSON.stringify(u))
    setUser(u)
  }

  const logout = () => {
    localStorage.removeItem('rmf_user')
    setUser(null)
  }

  return <Ctx.Provider value={{ user, login, logout }}>{children}</Ctx.Provider>
}

export function useAuth() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
