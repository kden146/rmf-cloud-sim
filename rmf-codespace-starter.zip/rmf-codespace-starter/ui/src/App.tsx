import React, { useEffect, useMemo, useState } from 'react'
import { Link, Navigate, Route, Routes } from 'react-router-dom'
import { AuthProvider, useAuth } from './lib/auth'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'

type AppConfig = { RMF_SERVER: string }

function useConfig() {
  const [cfg, setCfg] = useState<AppConfig | null>(null)
  const [err, setErr] = useState<string | null>(null)
  useEffect(() => {
    fetch('/config.json', { cache: 'no-store' })
      .then(r => r.ok ? r.json() : Promise.reject(r.statusText))
      .then((j: AppConfig) => setCfg(j))
      .catch(() => {
        // fallback to Vite env at build time
        const fallback = import.meta.env.VITE_RMF_SERVER || 'http://localhost:8000'
        setCfg({ RMF_SERVER: fallback })
      })
  }, [])
  return { cfg, err }
}

function TopBar({ server }: { server: string }) {
  const { user, logout } = useAuth()
  return (
    <div style={{display:'flex',gap:16,alignItems:'center',padding:'12px 16px',borderBottom:'1px solid #e2e8f0'}}>
      <strong>RMF UI</strong>
      <span style={{color:'#64748b'}}>API: {server}</span>
      <nav style={{display:'flex',gap:12}}>
        <Link to="/">Dashboard</Link>
        <Link to="/login">Login</Link>
      </nav>
      <div style={{marginLeft:'auto'}}>
        {user ? (
          <button onClick={logout}>Logout ({user.name})</button>
        ) : (
          <span style={{color:'#64748b'}}>Guest</span>
        )}
      </div>
    </div>
  )
}

function Protected({ children }: { children: React.ReactNode }) {
  const { user } = useAuth()
  if (!user) return <Navigate to="/login" replace />
  return <>{children}</>
}

export default function App() {
  const { cfg } = useConfig()
  if (!cfg) return <div style={{padding:20}}>Loading config…</div>
  return (
    <AuthProvider>
      <TopBar server={cfg.RMF_SERVER} />
      <Routes>
        <Route path="/" element={<Protected><Dashboard server={cfg.RMF_SERVER} /></Protected>} />
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AuthProvider>
  )
}
