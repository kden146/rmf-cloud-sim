import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../lib/auth'

export default function Login() {
  const [name, setName] = useState('Technician')
  const { login } = useAuth()
  const nav = useNavigate()

  return (
    <div style={{padding:24,maxWidth:420,margin:'40px auto',border:'1px solid #e2e8f0',borderRadius:12}}>
      <h2 style={{marginTop:0}}>Login (Mock)</h2>
      <p style={{color:'#64748b'}}>This demo uses a simple local login so you can access the dashboard without configuring OIDC.</p>
      <label style={{display:'block',marginBottom:8}}>Display name</label>
      <input
        value={name}
        onChange={e=>setName(e.target.value)}
        style={{width:'100%',padding:'8px 10px',border:'1px solid #cbd5e1',borderRadius:8,marginBottom:12}}
      />
      <button
        onClick={()=>{login(name); nav('/') }}
        style={{padding:'8px 12px',border:'1px solid #0ea5e9',borderRadius:8,background:'#0ea5e9',color:'white'}}
      >
        Continue
      </button>
    </div>
  )
}
