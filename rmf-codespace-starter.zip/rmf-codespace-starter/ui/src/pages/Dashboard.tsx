import React, { useEffect, useState } from 'react'

export default function Dashboard({ server }: { server: string }) {
  const [status, setStatus] = useState<'idle' | 'ok' | 'error'>('idle')
  const [json, setJson] = useState<any>(null)
  const [err, setErr] = useState<string | null>(null)

  const ping = async () => {
    setStatus('idle'); setErr(null); setJson(null)
    try {
      const res = await fetch(`${server}/openapi.json`)
      if (!res.ok) throw new Error(res.status + ' ' + res.statusText)
      const j = await res.json()
      setJson(j)
      setStatus('ok')
    } catch (e:any) {
      setErr(e.message || String(e))
      setStatus('error')
    }
  }

  useEffect(() => { ping() }, [])

  return (
    <div style={{padding:24}}>
      <h2>Dashboard</h2>
      <p>Press the button to confirm the UI can reach the API via the Codespaces forwarded URL.</p>
      <button onClick={ping} style={{padding:'8px 12px',border:'1px solid #10b981',borderRadius:8,background:'#10b981',color:'white'}}>Ping API</button>
      <div style={{marginTop:16}}>
        {status === 'ok' && <pre style={{whiteSpace:'pre-wrap',background:'#0b1020',color:'#d1e7ff',padding:12,borderRadius:8,maxHeight:360,overflow:'auto'}}>{JSON.stringify(json, null, 2)}</pre>}
        {status === 'error' && <div style={{color:'#ef4444'}}>Error: {err}</div>}
      </div>
    </div>
  )
}
